
var HomePage = function(){

    this.div = $('#homePage');
    this.load();
}
HomePage.prototype.load = function() {


}
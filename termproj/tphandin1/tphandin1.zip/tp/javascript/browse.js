
var BrowsePage = function(){
    this.div = $('#browsePage');
    this.load();
}
BrowsePage.prototype.load = function() {


}